//
//  GZApiHelper.h
//  GZYD
//
//  Created by shiyong_li on 2017/5/25.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GZApiHelper : NSObject
+ (NSString *)apiLogin;
/**
 参数：
 {
 "docId":1
 "opinionType":部门意见
 "orgId":0-n 0为查全部部门/其他为部门意见
  "groupType":org  有参数非置顶意见 否则 置顶意见
 }
 */
+ (NSString *)apiGetStickyOpinionList;
@end
