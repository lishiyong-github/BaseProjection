//
//  SHBaseResponseModel.h
//  GZYD
//
//  Created by shiyong_li on 2017/5/23.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SHBaseResponseModel : NSObject
@property (nonatomic,copy) NSString *sessionState;/**< 提示信息 */
@property (nonatomic,strong) id result;
@property (nonatomic,assign) BOOL success;
@end
