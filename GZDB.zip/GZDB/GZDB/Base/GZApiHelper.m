//
//  GZApiHelper.m
//  GZYD
//
//  Created by shiyong_li on 2017/5/25.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import "GZApiHelper.h"
@implementation GZApiHelper
+ (NSString *)serviceApi
{
    return @"http://58.246.138.178:8105";
}
+ (NSString *)serverAddress{
   return [NSString stringWithFormat:@"%@/supervise/",[self serviceApi]];
}

+ (NSString *)urlWithAction:(NSString *)action
{
    return [NSString stringWithFormat:@"%@%@",[self serverAddress],action];
}

+ (NSString *)apiLogin
{
    return [NSString stringWithFormat:@"%@/GZMobileService/single/signOn.do?params=",[self serviceApi]];
}

+ (NSString *)apiGetStickyOpinionList
{
    return [self urlWithAction:@"opinion/getOpinionInfoList.do?"];
}@end
