//
//  SHBaseResponseModel.m
//  GZYD
//
//  Created by shiyong_li on 2017/5/23.
//  Copyright © 2017年 Dist. All rights reserved.
//

#import "SHBaseResponseModel.h"

@implementation SHBaseResponseModel
- (BOOL)success
{
    return [self.result isEqualToString:@"true"];
}
@end
