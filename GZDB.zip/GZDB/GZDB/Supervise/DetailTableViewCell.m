//
//  DetailTableViewCell.m
//  GZDB
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DetailTableViewCell.h"
#import "UIView+Line.h"
@interface DetailTableViewCell()

@end
@implementation DetailTableViewCell
- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self=[super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftTitle];
        [self.contentView addSubview:self.rightTitle];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void) myUpdateConstraints{
    //单元格左侧标题
    [self.leftTitle autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.leftTitle autoAlignAxisToSuperviewAxis:ALAxisHorizontal];

    //单元格右侧标题
    [self.rightTitle autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.rightTitle autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.rightTitle autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.leftTitle withOffset:10];
    
    [NSLayoutConstraint autoSetPriority:UILayoutPriorityRequired forConstraints:^{
        [self.leftTitle autoSetContentCompressionResistancePriorityForAxis:ALAxisHorizontal];
    }];

}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (UILabel *) leftTitle{
    if (!_leftTitle) {
        _leftTitle = [UILabel newAutoLayoutView];
        _leftTitle.textColor=[UIColor blackColor];
        [_leftTitle setTextAlignment:NSTextAlignmentLeft];
        _leftTitle.font = [UIFont systemFontOfSize:13];
    }
    return _leftTitle;
}

- (UILabel *) rightTitle{
    if (!_rightTitle) {
        _rightTitle = [UILabel newAutoLayoutView];
        _rightTitle.textColor = [UIColor blackColor];
        [_rightTitle setTextAlignment:NSTextAlignmentRight];
        _rightTitle.font = [UIFont systemFontOfSize:13];
    }
    return _rightTitle;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
