//
//  GZSupervisePageViewController.m
//  GZDB
//
//  Created by shiyong_li on 2017/8/2.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "GZSupervisePageViewController.h"
#import "GZSuperviseViewController.h"
#import "GZSuperviseSegmentView.h"

@interface GZSupervisePageViewController ()

@property (nonatomic,strong)GZSuperviseSegmentView *segmentView;

@end

@implementation GZSupervisePageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController.navigationBar setTranslucent:NO];
    [self configHeader];
    self.title = @"督办";
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    self.navigationItem se
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - overide
- (NSArray *)titles
{
    return @[@"任务处理",@"任务协办"];
}

- (void)configHeader
{
    [self.view addSubview:self.segmentView];
    [self.view setNeedsUpdateConstraints];
}

- (void)myUpdateViewConstraints
{
    [self.segmentView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(45, 0, 0, 0) excludingEdge:ALEdgeBottom];
    [self.segmentView autoSetDimension:ALDimensionHeight toSize:40];
}

- (GZSuperviseSegmentView *)segmentView
{
    if (!_segmentView) {
        _segmentView = [GZSuperviseSegmentView newAutoLayoutView];
        /*
         内容
         */
        //        @weakify(self);
        //        [_segmentView.clickSignal subscribeNext:^(RACTuple *values) {
        //            @strongify(self);
        //            NSInteger segmentIndex = [values.first integerValue];
        //            if (segmentIndex<2) {
        //                /*
        //                 内容
        //                 */
        //            }else{
        //                /*
        //                 内容
        //                 */
        //            }
        //        }];
    }
    return _segmentView;
}


- (UIViewController *)viewPager:(MBViewPagerController *)viewPager contentViewControllerForTabAtIndex:(NSUInteger)index
{
    GZSuperviseViewController *controller;
    if (index == 0) {
////        DocumentDetailViewModel *viewModel = [[DocumentDetailViewModel alloc]initWithModel:self.model];
//        DocumentDetailViewController *baseVC = [[DocumentDetailViewController alloc]initWithViewModel:viewModel];
//        baseVC.navi = self.navigationController;
//        baseVC.index = self.index;
        controller = [GZSuperviseViewController new];
    } else {
//        DocMatrialVC *matrialVC = [[DocMatrialVC alloc] initWithModel:self.model];
//        matrialVC.navi = self.navigationController;
        controller = [GZSuperviseViewController new];
    }
    controller.navController = self.navigationController;
    return controller;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
