//
//  GZSuperviseSegmentView.m
//  GZDB
//
//  Created by csh on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "GZSuperviseSegmentView.h"
#import "UIButton+Style.h"

#define AnimationTime 0.35
#define lineColor [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:1]
#define GRAYCOLOR_DARK [UIColor colorWithRed:100/255.0 green:100/255.0 blue:100/255.0 alpha:1]
#define BLUECOLOR [UIColor colorWithRed:34.0/255.0 green:152.0/255.0 blue:239.0/255.0 alpha:1]

@interface GZSuperviseSegmentView ()
//按钮
@property (nonatomic,strong) UIButton *firstButton;
@property (nonatomic,strong) UIButton *secondButton;
@property (nonatomic,strong) UIButton *thirdButton;

@property (nonatomic,strong) UIButton *selectedButton;
//分割线
@property (nonatomic,strong) UIView *firstLine;
@property (nonatomic,strong) UIView *secondLine;
@property (nonatomic,strong) UIView *topLine;
@property (nonatomic,strong) UIView *bottomLine;


@end

@implementation GZSuperviseSegmentView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addSubview:self.firstButton];
        [self addSubview:self.secondButton];
        [self addSubview:self.thirdButton];
        [self.secondButton addSubview:self.firstLine];
        [self.thirdButton addSubview:self.secondLine];
        [self addSubview:self.topLine];
        [self addSubview:self.bottomLine];
        [self setNeedsUpdateConstraints];
        
        [self configButton];
    }
    return self;
}

- (void)myUpdateConstraints
{
    //按钮
    NSArray *buttonArray = @[self.firstButton,self.secondButton,self.thirdButton];
    [self.firstButton autoPinEdgeToSuperviewEdge:ALEdgeTop];
    [self.firstButton autoPinEdgeToSuperviewEdge:ALEdgeBottom];
    [buttonArray autoDistributeViewsAlongAxis:ALAxisHorizontal alignedTo:ALAttributeHorizontal withFixedSpacing:0];
    [buttonArray autoMatchViewsDimension:ALDimensionHeight];    
    
    //分割线
    [self.firstLine autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(10, 0, 10, 0) excludingEdge:ALEdgeLeft];
    [self.secondLine autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(10, 0, 10, 0) excludingEdge:ALEdgeLeft];
    [self.topLine autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeBottom];
    [self.topLine autoSetDimension:ALDimensionHeight toSize:1];
    [self.bottomLine autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero excludingEdge:ALEdgeTop];
    [self.bottomLine autoSetDimension:ALDimensionHeight toSize:1];
    
    [@[self.firstLine,self.secondLine] autoSetViewsDimension:ALDimensionWidth toSize:1];
}

- (void)reset
{
    if (self.select && self.selectedButton) {
        self.select = NO;
        self.selectedButton.selected = NO;
        [self.selectedButton animationSelected];
        self.selectedButton = nil;
    }
}

- (void)configButton
{
    [self configButton:self.firstButton];
    [self configButton:self.secondButton];
    [self configButton:self.thirdButton];
    [self configActionButton:self.firstButton index:0];
    [self configActionButton:self.secondButton index:1];
    [self configActionButton:self.thirdButton index:2];
}

- (void)configButton:(UIButton *)button
{
    [button setBackgroundColor:[UIColor whiteColor]];
    [button swapImageText];
    [button setImageEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 30)];
    [button setTitleEdgeInsets:UIEdgeInsetsMake(0, 0, 0, 10)];
    [button setTitleColor:GRAYCOLOR_DARK forState:UIControlStateNormal];
    [button.titleLabel setFont:[UIFont systemFontOfSize:14]];
//    button.titleLabel.adjustsFontSizeToFitWidth = YES;//@csh 字体自适应
    [button setTitleColor:BLUECOLOR forState:UIControlStateSelected];
}

- (void)configActionButton:(UIButton *)button index:(NSInteger)index
{
    @weakify(self);
    [[button rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(UIButton *button) {
        @strongify(self);
        if (index<2) {
            if (self.select && [self.selectedButton isEqual:button]) {
                return ;
            }
            [self reset];
            [button animationSelected];
            self.select = !self.select;
            button.selected = self.select;
            self.selectedButton = button;
//            if (index == 0) {//@csh
//                [self.firstButton setTitle:@"统计表分类" forState:UIControlStateNormal];
//            }
//            if (index == 1) {
//                [self.firstButton setTitle:@"统计表类类类类" forState:UIControlStateNormal];
//            }
        }else{
            [button animationSelected];
            button.selected = !button.selected;
        }
    }];
}

- (UIButton *)firstButton
{
    if (!_firstButton) {
        _firstButton = [UIButton newAutoLayoutView];
        [_firstButton setNormalImage:@"doc_filter_n" selectedImage:@"doc_filter_s"];
        [_firstButton setTitle:@"统计表分类" forState:UIControlStateNormal];
    }
    return _firstButton;
}
- (UIButton *)secondButton
{
    if (!_secondButton) {
        _secondButton = [UIButton newAutoLayoutView];
        [_secondButton setNormalImage:@"doc_filter_n" selectedImage:@"doc_filter_s"];
        [_secondButton setTitle:@"超期状态" forState:UIControlStateNormal];
    }
    return _secondButton;
}
- (UIButton *)thirdButton
{
    if (!_thirdButton) {
        _thirdButton = [UIButton newAutoLayoutView];
        [_thirdButton setNormalImage:@"doc_filter_down" selectedImage:@"doc_filter_down"];
        [_thirdButton setTitle:@"办理时限" forState:UIControlStateNormal];
    }
    return _thirdButton;
}

- (UIView *)firstLine
{
    if (!_firstLine) {
        _firstLine = [UIView newAutoLayoutView];
        [_firstLine setBackgroundColor:lineColor];
    }
    return _firstLine;
}

- (UIView *)secondLine
{
    if (!_secondLine) {
        _secondLine = [UIView newAutoLayoutView];
        [_secondLine setBackgroundColor:lineColor];
    }
    return _secondLine;
}

- (UIView *)bottomLine
{
    if (!_bottomLine) {
        _bottomLine = [UIView newAutoLayoutView];
        [_bottomLine setBackgroundColor:lineColor];
    }
    return _bottomLine;
}

- (UIView *)topLine
{
    if (!_topLine) {
        _topLine = [UIView newAutoLayoutView];
        [_topLine setBackgroundColor:lineColor];
    }
    return _topLine;
}

- (RACSubject *)clickSignal
{
    if (!_clickSignal) {
        _clickSignal = [RACSubject subject];
    }
    return _clickSignal;
}

@end
