//
//  GZSuperviseTableViewCell.m
//  GZDB
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "GZSuperviseTableViewCell.h"
#import "UIView+Line.h"

#define GRAYCOLOR [UIColor colorWithRed:228/255.0 green:228/255.0 blue:228/255.0 alpha:1]

@interface GZSuperviseTableViewCell ()
@property (nonatomic, strong) UIImageView *iconImageView;
@end
@implementation GZSuperviseTableViewCell
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self.contentView addSubview:self.iconImageView];
        [self.contentView addSubview:self.titleLabel];
        [self.contentView addSubview:self.detailLabel];
        [self.contentView addSubview:self.timeLable];
        [self setNeedsUpdateConstraints];
        [self.contentView addBottomLine];
    }
    return self;
}

- (void)myUpdateConstraints
{
    //单元格左侧的图标
    [self.iconImageView autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:15];
    [self.iconImageView autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    [self.iconImageView autoSetDimensionsToSize:CGSizeMake(20, 20)];

    //单元格上侧的主标题
    [self.titleLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.iconImageView withOffset:10];
    [self.titleLabel autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
    [self.titleLabel autoPinEdge:ALEdgeRight toEdge:ALEdgeLeft ofView:self.timeLable withOffset:10];
    
    //单元格下侧的副标题
    [self.detailLabel autoPinEdge:ALEdgeLeft toEdge:ALEdgeRight ofView:self.iconImageView withOffset:10];
    [self.detailLabel autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.titleLabel withOffset:6];
    [self.detailLabel autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    //单元格右侧的时间显示框
    [self.timeLable autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.timeLable autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:10];
}

- (UILabel *) titleLabel {
    if (!_titleLabel) {
        _titleLabel = [UILabel newAutoLayoutView];
        [_titleLabel setTextAlignment:NSTextAlignmentLeft];
        [_titleLabel setTextColor:[UIColor blackColor]];
        [_titleLabel setFont:[UIFont systemFontOfSize:15]];
    }
    return _titleLabel;
}

- (UILabel *) detailLabel {
    if (!_detailLabel) {
        _detailLabel = [UILabel newAutoLayoutView];
        [_detailLabel setTextColor:GRAYCOLOR];
        [_detailLabel setFont:[UIFont systemFontOfSize:13]];
    }
    return _detailLabel;
}

- (UILabel *) timeLable {
    if (!_timeLable) {
        _timeLable = [UILabel newAutoLayoutView];
        [_timeLable setTextColor:GRAYCOLOR];
        [_timeLable setFont:[UIFont systemFontOfSize:15]];
    }
    return _timeLable;
}


#pragma mark - getter
- (UIImageView *)iconImageView
{
    if (!_iconImageView) {
        _iconImageView = [UIImageView newAutoLayoutView];
        [_iconImageView setBackgroundColor:[UIColor redColor]];
    }
    return _iconImageView;
}
@end
