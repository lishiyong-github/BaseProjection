//
//  ProjectInfoTableViewCell.h
//  GZDB
//
//  Created by Wu Longfei on 2017/8/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProjectInfoTableViewCell : UITableViewCell
@property(strong,nonatomic) UILabel *leftTitle;
@property(strong,nonatomic) UILabel *rightTitle;
@end
