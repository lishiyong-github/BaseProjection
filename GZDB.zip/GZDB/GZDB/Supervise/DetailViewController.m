//
//  DetailViewController.m
//  GZDB
//
//  Created by Wu Longfei on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "DetailViewController.h"
#import "DetailTableViewCell.h"
#import "ProjectInfoViewController.h"
@interface DetailViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (strong,nonatomic) UITableView *tableView;
@property (strong,nonatomic) NSArray *leftTittleArray;
@property (strong,nonatomic) NSArray *rightTitleArray;
//@property (strong,nonatomic) 
@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    _leftTittleArray = [NSArray array];
    _rightTitleArray = [NSArray array];
    _leftTittleArray = @[@"督办主题",@"发起日期",@"办理期限",@"关键词",@"统计表分类",@"考核分类",@"牵头领导",@"主办单位",@"督办发起人",@"任务类型",@"任务描述"];
    _rightTitleArray = @[@"中共广州市委办公厅广州市人民政府办公厅印《关于贯彻落实中共广州市委十届九次全会决策》的通知",@"2016-10-26",@"2016-12-01",@"限时办结 上级部门来函",@"其它重点督办事项",@"",@"李秋霞",@"监检处",@"",@"",@""];
    [self creatTableView];
}

//创建表视图
- (void) creatTableView{
    UITableView *tableView                      = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
    tableView.dataSource                        = self;
    tableView.delegate                          = self;
    tableView.separatorStyle                    = UITableViewCellSelectionStyleNone;
    _tableView                                  = tableView;
    [self.view addSubview:_tableView];
}

#pragma mark -UITableViewDelegate,UITableViewDataSources

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [_leftTittleArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier                 = @"cell";
    DetailTableViewCell *cell                   = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell                                    = [[DetailTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.leftTitle.text                     = [_leftTittleArray objectAtIndex:indexPath.row];
        cell.rightTitle.text                    = [_rightTitleArray objectAtIndex:indexPath.row];
        cell.rightTitle.numberOfLines           = 0;
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    ProjectInfoViewController *projectVC = [[ProjectInfoViewController alloc] init];
    [self.navigationController pushViewController:projectVC animated:YES];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
