//
//  GZSuperviseViewController.m
//  GZDB
//
//  Created by shiyong_li on 2017/7/31.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "GZSuperviseViewController.h"
#import "GZSuperviseSegmentView.h"
#import "GZSuperviseTableViewCell.h"
#import "DetailViewController.h"

@interface GZSuperviseViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (strong,nonatomic) UITableView *TableView;
@property (strong,nonatomic) NSArray *titleDataArray;
@property (strong,nonatomic) NSArray *detailDataArray;
@property (strong,nonatomic) NSArray *timeDataArray;
@property (nonatomic,strong)GZSuperviseSegmentView *segmentView;

@end

@implementation GZSuperviseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self configHeader];
    _titleDataArray       = [NSArray array];
    _detailDataArray      = [NSArray array];
    _timeDataArray        = [NSArray array];
    _titleDataArray       = @[@"中共广州市委办公厅广州市人民政府办公厅印发",
                              @"征求对《广州市国土规划委的正确决定》",
                              @"广州市环保局关于广州市委的重要决定的会议",
                              @"关于安排广州市建设用地推介平台在政府各部门之间的使用",
                              @"关于对督办系统进行修改完善的请示",
                              @"广州市审计局关于定期报送电子数据",
                              @"征求对《广州市国土规划委发展规划的重要决定》的意见",
                              @"关于征求《国土规划局行政审议的规定》的意见"];
    
    _detailDataArray      = @[@"2016000101000130",
                              @"2016000101000014",
                              @"2016000101000013",
                              @"2016000101000012",
                              @"2016000101000008",
                              @"2016000101000006",
                              @"2016000101000004",
                              @"2016000101000003"];
    
    _timeDataArray       = @[@"2016/12/28",@"每月20日",@"2016/12/23",@"每月10号",@"2016/12/22",@"每月5号",@"2016/12/21",@"2016/12/21"];

    
    //创建表视图
    [self creatTableView];

    // Do any additional setup after loading the view.
}

- (void)configHeader
{
    [self.view addSubview:self.segmentView];
    [self.view setNeedsUpdateConstraints];
}

- (void)myUpdateViewConstraints
{
    [self.segmentView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(40 + 45, 0, 0, 0) excludingEdge:ALEdgeBottom];
    [self.segmentView autoSetDimension:ALDimensionHeight toSize:40];
}

- (GZSuperviseSegmentView *)segmentView
{
    if (!_segmentView) {
        _segmentView = [GZSuperviseSegmentView newAutoLayoutView];
        /*
        内容
         */
//        @weakify(self);
//        [_segmentView.clickSignal subscribeNext:^(RACTuple *values) {
//            @strongify(self);
//            NSInteger segmentIndex = [values.first integerValue];
//            if (segmentIndex<2) {
//                /*
//                 内容
//                 */
//            }else{
//                /*
//                 内容
//                 */
//            }
//        }];
    }
    return _segmentView;
}

- (void) creatTableView {
    UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0,0, SCREEN_WIDTH, SCREEN_HEIGHT) style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
//    tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    _TableView = tableView;
    [self.view addSubview:_TableView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma UITableViewDelegate,UITableViewDatasources
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [_titleDataArray count];//[_dataArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    GZSuperviseTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (cell == nil) {
        cell=[[GZSuperviseTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.timeLable.text = [_timeDataArray objectAtIndex:indexPath.row];
        cell.titleLabel.text = [_titleDataArray objectAtIndex:indexPath.row] ;
        cell.detailLabel.text =[_detailDataArray objectAtIndex:indexPath.row];
    }
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    DetailViewController *docDetailVC = [[DetailViewController alloc] init];
    [self.navigationController pushViewController:docDetailVC animated:YES];
}



#pragma mark - getter
- (UINavigationController *)navigationController
{
    return self.navController;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
