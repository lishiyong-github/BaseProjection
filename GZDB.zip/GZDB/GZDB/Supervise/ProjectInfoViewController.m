//
//  ProjectInfoViewController.m
//  GZDB
//
//  Created by Wu Longfei on 2017/8/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ProjectInfoViewController.h"
#import "ProjectInfoTableViewCell.h"
//#import "ProjectButtomTableViewCell.h"

@interface ProjectInfoViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (strong,nonatomic) UITableView *tableViewUp;
@property (nonatomic ,strong) NSArray *leftTitleArray;
@property (nonatomic ,strong) NSArray *rightTitleArray;
@end

@implementation ProjectInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.automaticallyAdjustsScrollViewInsets = NO;
    self.extendedLayoutIncludesOpaqueBars = YES;
    self.edgesForExtendedLayout =UIRectEdgeNone;
    //加载单元格
    [self creatTableView];
    _leftTitleArray = [NSArray array];
    _rightTitleArray = [NSArray array];
    _leftTitleArray = @[@"主办单位",@"督办发起人",@"任务类型",@"任务描述",@"信息"];
    _rightTitleArray = @[@"监检处",@"",@"",@"",@""];
}

- (void) creatTableView{
    //创建单元格
    UITableView *tableViewUp              = [UITableView newAutoLayoutView];
    tableViewUp.dataSource                = self;
    tableViewUp.delegate                  = self;
    tableViewUp.separatorStyle            = UITableViewCellSeparatorStyleNone;
    _tableViewUp                          = tableViewUp;
    [self.view addSubview:_tableViewUp];
    [self.tableViewUp autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsZero];
}

//实现代理方法、数据源方法
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    switch (section) {
        case 0:
            return 5;
            break;
        case 1:
            return 1;
            break;
        case 2:
            return 1;
            break;
        default:
            return 0;
            break;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section==0) {
        return 0;
    }
    return 40;
}

- (NSString *) tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    switch (section) {
        case 0:
            return nil;
            break;
        case 1:
            return @"section1";
            break;
        case 2:
            return @"section2";
            break;
        default:
            return nil;
            break;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *identifier         = @"cell";
    ProjectInfoTableViewCell *cell      = [tableView dequeueReusableCellWithIdentifier:identifier ];
    if (cell == nil) {
        cell                            = [[ProjectInfoTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.leftTitle.text             = [_leftTitleArray objectAtIndex:indexPath.row];
        cell.rightTitle.text            = [_rightTitleArray objectAtIndex:indexPath.row];
    }
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section!=0) {
        UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 40)];
        headerView.backgroundColor = [UIColor whiteColor];
        
        //添加右侧按钮
        UIButton *rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
        rightButton.backgroundColor = [UIColor redColor];
        rightButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
//        rightButton.frame = CGRectMake(0, 0, self.view.frame.size.width, 40);
//        rightButton.imageEdgeInsets = UIEdgeInsetsMake(10, SCREEN_WIDTH-30, 10, 10);
        [rightButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
        [headerView addSubview:rightButton];
        [tableView.tableHeaderView addSubview:headerView];

        return headerView;
  
    }else{
        return nil;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{

}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 55;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
