//
//  ProjectInfoTableViewCell.m
//  GZDB
//
//  Created by Wu Longfei on 2017/8/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "ProjectInfoTableViewCell.h"
#import "UIView+Line.h"
@interface ProjectInfoTableViewCell()

@end


@implementation ProjectInfoTableViewCell

- (instancetype) initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self.contentView addSubview:self.leftTitle];
        [self.contentView addSubview:self.rightTitle];
        [self.contentView addBottomLine];
    }
    return self;
}

- (UILabel *) leftTitle{
    if (!_leftTitle) {
        _leftTitle = [UILabel newAutoLayoutView];
        _leftTitle.textColor = [UIColor blackColor];
        _leftTitle.font = [UIFont systemFontOfSize:13];
    }
    return _leftTitle;

}

- (UILabel *) rightTitle{
    if (!_rightTitle) {
        _rightTitle = [UILabel newAutoLayoutView];
        _rightTitle.textColor = [UIColor blackColor];
        _rightTitle.font = [UIFont systemFontOfSize:13];
    }
    return  _rightTitle;
}

- (void) myUpdateConstraints{
    //设置左侧标题距离左侧30px
    [self.leftTitle autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:10];
    [self.leftTitle autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
    
    //设置右侧标题距离右侧30px
    [self.rightTitle autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:10];
    [self.rightTitle autoAlignAxisToSuperviewAxis:ALAxisHorizontal];
}
- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
