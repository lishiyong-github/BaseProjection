//
//  LoginViewController.m
//  GZDB
//
//  Created by csh on 2017/8/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "LoginViewController.h"
#import "loginBackView.h"
#import "GZSupervisePageViewController.h"
#import "UIViewController+Login.h"

#define SCREEN_WIDTH   [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height
#define BACKGROUNDCOLOR [UIColor colorWithRed:255/255.0 green:255/255.0 blue:255/255.0 alpha:0.7]
// 震动动画没加
@interface LoginViewController ()<UIScrollViewDelegate,UITextFieldDelegate>

@property (nonatomic,strong) UIScrollView  *scrollView;
@property (nonatomic,strong) loginBackView *loginBackView;
@property (nonatomic,strong) NSTimer *timer;

@end

@implementation LoginViewController

#pragma mark - override
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.loginBackView endEditing:YES];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.navigationController.navigationBar.hidden = YES;
    self.navigationController.interactivePopGestureRecognizer.enabled = NO;
    // 背景动画
    if (!self.timer) {
        self.timer = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(scrollAnimation) userInfo:nil repeats:YES];
    }
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBar.hidden = NO;
    
    // 停止
    [_timer invalidate];
    _timer = nil;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    [self.scrollView autoSetDimensionsToSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT)];
    // 设置登录初始状态
    [self setLoginViewOriginalState];
    // 背景动画
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        [self createBackAnimationView];
    });
    [self configLoginView];
    [LSYKeyBoardManager keyboadWithObserverView:self.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)configLoginView
{
    [self.view addSubview:self.loginBackView];
    [self.view setNeedsUpdateConstraints];
}



- (void)myUpdateViewConstraints
{
    
//    [self.loginBackView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(120, 26, 0, 26) excludingEdge:ALEdgeBottom];
//    [self.loginBackView autoSetDimension:ALDimensionHeight toSize:300];

    [self.loginBackView autoSetDimensionsToSize:CGSizeMake(300, 300)];
    [self.loginBackView autoCenterInSuperview];
}

#pragma mark -- 设置登录界面初始状态
- (void)setLoginViewOriginalState
{
    self.loginBackView.layer.cornerRadius= 6;
    self.loginBackView.layer.masksToBounds = YES;
}

- (void)createBackAnimationView
{
    if (!_scrollView) {
        UIImage *backImage = [UIImage imageNamed:@"loginImage.jpg"];
        UIScrollView *scroll = [UIScrollView newAutoLayoutView];
        scroll.contentSize = CGSizeMake(SCREEN_WIDTH + 150, SCREEN_HEIGHT);
        scroll.contentOffset = CGPointMake(0, 0);
        scroll.bounces = NO;
        scroll.delegate = self;
        scroll.showsHorizontalScrollIndicator = NO;
        scroll.showsVerticalScrollIndicator = NO;
        scroll.userInteractionEnabled = NO;
        _scrollView = scroll;
        UIImageView *imageView = [UIImageView newAutoLayoutView];
//        imageView.contentMode = UIViewContentModeScaleAspectFit;
        imageView.image = backImage;
        [scroll addSubview:imageView];
        [self.view addSubview:scroll];
        [imageView autoPinEdgesToSuperviewEdgesWithInsets:UIEdgeInsetsMake(0, 0, 0, -150)];
//        [scroll autoPinEdgesToSuperviewEdges];
        [scroll autoMatchDimension:ALDimensionHeight toDimension:ALDimensionWidth ofView:scroll withMultiplier:1.3];
        [scroll autoCenterInSuperview];
        [scroll autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:0 relation:NSLayoutRelationLessThanOrEqual];
        [scroll autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:0 relation:NSLayoutRelationLessThanOrEqual];
//        [scroll autoSetDimensionsToSize:CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT)];
        [self.view bringSubviewToFront:self.loginBackView];
    }
}

-(loginBackView *)loginBackView
{
    if (!_loginBackView) {
        _loginBackView = [loginBackView newAutoLayoutView];
        [_loginBackView setBackgroundColor:BACKGROUNDCOLOR];
        @weakify(self);
        [_loginBackView.clickSignal subscribeNext:^(RACTuple *value) {
            @strongify(self);
            [[self loginWithUsername:value.first password:value.second] subscribeNext:^(id x) {
                @strongify(self);
                [self loginSuccess];
            }];
        }];
    }
    return _loginBackView;
}
#pragma mark - login action

- (void)loginSuccess
{
    CATransition *transition = [CATransition animation];
    transition.duration = 1.8;
    transition.type = @"rippleEffect";
    //transition.type = @"cube";
    transition.subtype = kCATransitionFromRight;
    [_scrollView.layer addAnimation:transition forKey:nil];
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        GZSupervisePageViewController *controller = [[GZSupervisePageViewController alloc]init];
        UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:controller];
        [UIApplication sharedApplication].keyWindow.rootViewController = nav;
    });
}
#pragma mark -- 背景图滑动动画
- (void)scrollAnimation
{
    static BOOL isLeft = YES;
    if (isLeft)
    {
        [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x + 4.0, _scrollView.contentOffset.y) animated:YES];
        if (self.scrollView.contentOffset.x >= self.scrollView.contentSize.width - SCREEN_WIDTH - 10.0)
        {
            isLeft = NO;
        }
    }
    else
    {
        [self.scrollView setContentOffset:CGPointMake(self.scrollView.contentOffset.x - 4.0, self.scrollView.contentOffset.y) animated:YES];
        if (self.scrollView.contentOffset.x <= 10.0)
        {
            isLeft = YES;
        }
    }
}

@end
