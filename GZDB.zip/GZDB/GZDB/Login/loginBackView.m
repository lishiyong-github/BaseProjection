//
//  loginBackView.m
//  GZDB
//
//  Created by csh on 2017/8/1.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "loginBackView.h"
#import "UIButton+Style.h"

#define SCREEN_WIDTH   [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT   [[UIScreen mainScreen] bounds].size.height
#define buttonColor [UIColor colorWithRed:34/255.0 green:152/255.0 blue:239/255.0 alpha:1]
#define lineColor [UIColor colorWithRed:200/255.0 green:200/255.0 blue:200/255.0 alpha:1]

@interface loginBackView () <UITextFieldDelegate,UIAlertViewDelegate>

@property (nonatomic,strong) UIImageView *imageView;
@property (nonatomic,strong) UIImageView *userNameImage;
@property (nonatomic,strong) UIImageView *passWordImage;
@property (nonatomic,strong) UITextField *userNameText;
@property (nonatomic,strong) UITextField *passWordText;
@property (nonatomic,strong) UIButton    *rememberButton;
@property (nonatomic,strong) UIButton    *autoLoginButton;
@property (nonatomic,strong) UIButton    *loginButton;
@property (nonatomic,strong) UIView      *firstBottomLine;
@property (nonatomic,strong) UIView      *secondBottomLine;

@end

@implementation loginBackView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self addSubview:self.imageView];
        [self addSubview:self.userNameImage];
        [self addSubview:self.userNameText];
        [self addSubview:self.passWordImage];
        [self addSubview:self.passWordText];
        [self addSubview:self.rememberButton];
//        [self addSubview:self.rememberLabel];
        [self addSubview:self.autoLoginButton];
//        [self addSubview:self.autoLoginLabel];
        [self addSubview:self.loginButton];
        [self addSubview:self.firstBottomLine];
        [self addSubview:self.secondBottomLine];
        [self setNeedsUpdateConstraints];
        
    }
    return self;
}

- (void)myUpdateConstraints
{
    [self.imageView autoSetDimensionsToSize:CGSizeMake(80, 80)];
    [self.imageView autoAlignAxisToSuperviewAxis:ALAxisVertical];
    [self.imageView autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:17];
    
    [self.userNameImage autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.userNameImage autoPinEdgeToSuperviewEdge:ALEdgeTop withInset:125];
    [self.userNameImage autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:42];
    
    [self.userNameText autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:72];
    [self.userNameText autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:34];
    [self.userNameText autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.imageView withOffset:24 relation:NSLayoutRelationEqual];
    [self.userNameText autoSetDimension:ALDimensionHeight toSize:30];
    
    [self.firstBottomLine autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:34];
    [self.firstBottomLine autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:34];
    [self.firstBottomLine autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.userNameText withOffset:1 relation:NSLayoutRelationEqual];
    [self.firstBottomLine autoSetDimension:ALDimensionHeight toSize:1];


    [self.passWordImage autoSetDimensionsToSize:CGSizeMake(20, 20)];
    [self.passWordImage autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.userNameImage withOffset:29 relation:NSLayoutRelationEqual];
    [self.passWordImage autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:42];
    
    [self.passWordText autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:72];
    [self.passWordText autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:34];
    [self.passWordText autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.userNameText withOffset:18 relation:NSLayoutRelationEqual];
    [self.passWordText autoSetDimension:ALDimensionHeight toSize:30];
    
    [self.secondBottomLine autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:34];
    [self.secondBottomLine autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:34];
    [self.secondBottomLine autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passWordText withOffset:1 relation:NSLayoutRelationEqual];
    [self.secondBottomLine autoSetDimension:ALDimensionHeight toSize:1];
    
    [self.rememberButton autoSetDimensionsToSize:CGSizeMake(90, 21)];
    [self.rememberButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passWordText withOffset:21 relation:NSLayoutRelationEqual];
    [self.rememberButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:42];
    
    [self.autoLoginButton autoSetDimensionsToSize:CGSizeMake(90, 21)];
    [self.autoLoginButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:35];
    [self.autoLoginButton autoPinEdge:ALEdgeTop toEdge:ALEdgeBottom ofView:self.passWordText withOffset:21 relation:NSLayoutRelationEqual];
    
    [self.loginButton autoSetDimension:ALDimensionHeight toSize:36];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeBottom withInset:15];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeLeft withInset:34];
    [self.loginButton autoPinEdgeToSuperviewEdge:ALEdgeRight withInset:34];
    
    _userNameText.delegate = self;
    _passWordText.delegate = self;
    _passWordText.secureTextEntry = YES;
}

- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [UIImageView newAutoLayoutView];
        [_imageView setImage:[UIImage imageNamed:@"logo"]];
    }
    return _imageView;
}

- (UIImageView *)userNameImage
{
    if (!_userNameImage) {
        _userNameImage = [UIImageView newAutoLayoutView];
        [_userNameImage setImage:[UIImage imageNamed:@"userName"]];
    }
    return _userNameImage;
}

- (UITextField *)userNameText
{
    if (!_userNameText) {
        _userNameText = [UITextField newAutoLayoutView];
    }
    return _userNameText;
}

- (UIImageView *)passWordImage
{
    if (!_passWordImage) {
        _passWordImage = [UIImageView newAutoLayoutView];
        [_passWordImage setImage:[UIImage imageNamed:@"passWord"]];
    }
    return _passWordImage;
}

- (UITextField *)passWordText
{
    if (!_passWordText) {
        _passWordText = [UITextField newAutoLayoutView];
    }
    return _passWordText;
}

- (UIButton *)rememberButton
{
    if (!_rememberButton) {
        _rememberButton = [UIButton newAutoLayoutView];
        [_rememberButton setNormalImage:@"unselect" selectedImage:@"select"];
        [_rememberButton setTitle:@"记住密码" forState:UIControlStateNormal];
        [_rememberButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_rememberButton setImageEdgeInsets:UIEdgeInsetsMake(3, 0, 3, 75)];
        [_rememberButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -21, 0, 0)];
        _rememberButton.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        @weakify(self);
        [[_rememberButton addAction] subscribeNext:^(id x) {
           @strongify(self);
            self.rememberButton.selected = !self.rememberButton.selected;
        }];
    }
    return _rememberButton;
}

- (UIButton *)autoLoginButton
{
    if (!_autoLoginButton) {
        _autoLoginButton = [UIButton newAutoLayoutView];
        [_autoLoginButton setNormalImage:@"unselect" selectedImage:@"select"];
        [_autoLoginButton setTitle:@"自动登录" forState:UIControlStateNormal];
        [_autoLoginButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [_autoLoginButton setImageEdgeInsets:UIEdgeInsetsMake(3, 0, 3, 75)];
        [_autoLoginButton setTitleEdgeInsets:UIEdgeInsetsMake(0, -21, 0, 0)];
        _autoLoginButton.titleLabel.font = [UIFont systemFontOfSize:14.0f];
        @weakify(self);
        [[_autoLoginButton addAction] subscribeNext:^(id x) {
            @strongify(self);
            self.autoLoginButton.selected = !self.autoLoginButton.selected;
        }];
    }
    return _autoLoginButton;
}

- (UIButton *)loginButton
{
    if (!_loginButton) {
        _loginButton = [UIButton newAutoLayoutView];
        [_loginButton setTitle:@"确定" forState:UIControlStateNormal];
        _loginButton.titleLabel.font = [UIFont systemFontOfSize:18.0f];
        [_loginButton.layer setCornerRadius:6.0f];
        [_loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_loginButton setBackgroundColor:buttonColor];
        @weakify(self);
        [[_loginButton addAction] subscribeNext:^(id x) {
           @strongify(self);
            [self login];
        }];
    }
    return _loginButton;
}

- (UIView *)firstBottomLine
{
    if (!_firstBottomLine) {
        _firstBottomLine = [UIView newAutoLayoutView];
        [_firstBottomLine setBackgroundColor:lineColor];
    }
    return _firstBottomLine;
}

- (UIView *)secondBottomLine
{
    if (!_secondBottomLine) {
        _secondBottomLine = [UIView newAutoLayoutView];
        [_secondBottomLine setBackgroundColor:lineColor];
    }
    return _secondBottomLine;
}

- (RACSubject *)clickSignal
{
    if (!_clickSignal) {
        _clickSignal = [RACSubject subject];
    }
    return _clickSignal;
}

#pragma mark -- 登录
- (void)login
{
    [self.userNameText resignFirstResponder];
    [self.passWordText resignFirstResponder];
    
    if ([self.userNameText.text  isEqual: @""]) {
        //没使用MBProgressHUD框架
        UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"请输入用户名" message:nil delegate:nil cancelButtonTitle:@"好的" otherButtonTitles:nil, nil];
        [alert show];
        return;
    }
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setValue:self.userNameText.text forKey:@"userName"];
    [userDefaults setValue:self.passWordText.text forKey:@"passWord"];
    
    [self loginClick];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [alertView dismissWithClickedButtonIndex:buttonIndex animated:NO];
    }
}

- (void)loginClick
{
    [self.clickSignal sendNext:RACTuplePack(self.userNameText.text,self.passWordText.text)];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self endEditing:YES];
}

@end
