//
//  UIViewController+Login.m
//  GZDB
//
//  Created by csh on 2017/8/2.
//  Copyright © 2017年 shiyong_li. All rights reserved.
//

#import "UIViewController+Login.h"

@implementation UIViewController (Login)
- (RACSignal *)loginWithUsername:(NSString *)userName password:(NSString *)password
{
    @weakify(self);
    return [RACSignal startEagerlyWithScheduler:[RACScheduler scheduler] block:^(id<RACSubscriber> subscriber) {
        NSString *url = [GZApiHelper apiLogin];
        NSString *params = [NSString stringWithFormat:@"username=%@,password=%@,supervise",userName,password];
        params = [DES encryptUseDES:params key:DESkey];
        url = [url stringByAppendingString:params];
        @strongify(self);
        [(SHNetWorkViewController *)self postUrl:url success:^(NSDictionary *json) {
            SHBaseResponseModel *response = [SHBaseResponseModel mj_objectWithKeyValues:json];
            if (response.success) {
                NSString *ticket = [json objectForKey:kTicket];
                ticket = [ticket stringByReplacingOccurrencesOfString:@"=" withString:@"=="];
                [UserDefaults setObject:ticket forKey:kTicket];
                [UserDefaults synchronize];
                [subscriber sendNext:@1];
            }
            [subscriber sendCompleted];
        } failed:^{
            [subscriber sendError:nil];
        }];
    }];
}
@end
